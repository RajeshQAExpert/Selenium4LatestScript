package webTable;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class DynamixWebTableWay2 {

	public static void main(String[] args) {
		
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demo.guru99.com/test/web-table-element.php");
		
		driver.findElement(By.xpath("//*[text()='All']")).click();
		
		
		List<WebElement> eleHead = driver.findElements(By.xpath("//table[@class='dataTable']/tbody/tr"));
		int cInt = eleHead.size();
		System.out.println(cInt);
		
		//You can choose the below syntax if you want to print all the table values otherwise skip this.
		for (WebElement hCol : eleHead) {
			System.out.println(hCol.getText());
		}
		
		for (int i = 1; i <=cInt; i++) {
			WebElement auName = driver.findElement(By.xpath("//table[@class='dataTable']/tbody/tr["+i+"]/td[1]"));
			if (auName.getText().equalsIgnoreCase("Sun Pharma.")) {
				WebElement country = driver.findElement(By.xpath("//table[@class='dataTable']/tbody/tr["+i+"]/td[4]"));
				System.out.println(country.getText());
				
			}
			
		}
		
		
	}

}
