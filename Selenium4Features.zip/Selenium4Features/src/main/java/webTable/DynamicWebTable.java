package webTable;

import org.openqa.selenium.chrome.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DynamicWebTable {
	
	
	/*
	  Tagname of the table is <table class="WebTable" /> 
	  
	  tr = table row 
	  th = table header 
	  td = table data
	 
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();					//Selenium Manager v4.6.0 onwards 
		driver.manage().window().maximize();
		driver.get("https://demo.guru99.com/test/web-table-element.php");
		
		//driver.findElement(By.xpath("//*[text()='All']")).click();
		
		
		
		//getColumnCount
		int columns = driver.findElements(By.xpath("//*[@class='dataTable']//th")).size();
		
		//--------------------------------------------------------------------------------
		//It will print all the values in the table
		/*for(int r=1; r<=rows-1; r++) {
			for(int c=1; c<=columns; c++) {
				
			String tableValues =  driver.findElement(By.xpath("//*[@class='dataTable']/tbody/tr["+r+"]/td["+c+"]")).getText();
			System.out.print(tableValues+ "   ");
			
			}
			System.out.println();
		} */
		//--------------------------------------------------------------------------------
		
		//Print the particular value in the table
		
		//getRowcount 		
				int rows = driver.findElements(By.xpath("//*[@class='dataTable']//tr")).size();
		
		for(int i=1; i<=rows-1; i++) {
			
			//To print all the values from the table
			/*		 
			String company = driver.findElement(By.xpath("//*[@class='dataTable']/tbody/tr["+i+"]")).getText();
			System.out.println(company);
			*/
			
			
			String company = driver.findElement(By.xpath("//*[@class='dataTable']/tbody/tr["+i+"]/td[1]")).getText();
			if(company.equals("Sun Pharma.")) {
				String expectedValue = driver.findElement(By.xpath("//*[@class='dataTable']/tbody/tr["+i+"]/td[4]")).getText();
				System.out.println(company+ " " + expectedValue);
			} 
		}
		

	}

}
