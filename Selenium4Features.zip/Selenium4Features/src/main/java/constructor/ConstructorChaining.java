package constructor;

public class ConstructorChaining {
	
	
	/*
	 Constructor Chaining: 
	 	
	 		Constructor chaining is the process of calling one constructor from another constructor
	 		with respect to the current object.
	 		
	 		-------------------------------------------------------
	 						
	 Why do we need constructor chaining: 
	 
	 		When we want to perform multiple tasks in a single constructor rather than creating a code for each task
	 		In a single constructor we create a separate constructor for each task and make their chain which makes
	 		the program more readable. 
	 		
	 		-------------------------------------------------------

	 
	 Rules of constructor chaining within the same class:
		
			The this() expression should always be the first line of the constructor 
			There should be at-least be on constructor without the this() keyword
			Constructor chaining can be achieved in any order
			
	 		-------------------------------------------------------
	 		
	 		
	 		WHich constructor will call first in the below program: 
	 		
	 		public class parentConstructor{
	 		
	 			public parentConstructor(){
	 			System.out.println("this is parent class constructor"); 
	 		}
	 		
	 		
	 		public class childConstructor extends paretnConstructor{
	 		public childConstructor(){
	 		System.out.println("this is child class constructor");
	 		 }
	 		}
	 		
	 		class executableClass{
	 		
	 		childConstructor cObj = new childConstructor(); 
	 		
	 		//Created object for the child class. In this case parent class constructor will call first then
	 		 							child class constructor will be calling. 
	 		
	 		
	 		}
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
			new demoCon()
			.practice(10);
			
			
	
	}

}
