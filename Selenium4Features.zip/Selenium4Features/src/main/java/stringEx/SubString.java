package stringEx;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.*;

public class SubString {

	/*
	 
	 In Java, the substring() method is used to extract a portion of a string. It takes either one or two parameters: 
	 the starting index (inclusive) and optionally the ending index (exclusive) of the substring
	 
	 String str = "Hello, World!";
	String substr = str.substring(7); // Extracts from index 7 to the end
	System.out.println(substr); // Output: World!

	 String str = "Hello, World!";
	String substr = str.substring(7, 12); // Extracts from index 7 to 11
	System.out.println(substr); // Output: World

	String str = "Hello, World!";
	int startIndex = str.indexOf(",") + 2; // Finds the index of comma and adds 2 to get the starting index
	String substr = str.substring(startIndex); // Extracts from the comma and the space after it
	System.out.println(substr); // Output: World!
 
	 */
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "Showing 1 to 20 of 8511 (426 pages) ";  //You need to print only 426 alone
		int a = str.indexOf("(")+1;
		int b = str.indexOf("pages")-1;

		int pages = Integer.valueOf(str.substring(a,b));
		System.out.println(pages);
		
		//Integer.valueOf = used to convert the string to integer
		
	}

}
