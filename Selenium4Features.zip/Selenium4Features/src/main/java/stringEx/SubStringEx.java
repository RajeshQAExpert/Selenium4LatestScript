package stringEx;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.*;

public class SubStringEx {
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "Showing 1 to 20 of 8511 (426 pages) ";  //You need to print only 426 alone
		int a = str.indexOf("(")+1;
		int b = str.indexOf("pages")-1;

		int pages = Integer.valueOf(str.substring(a,b));
		System.out.println(pages);
		
		//Integer.valueOf = used to convert the string to integer
		
		
		/* Using index 
		String val = str.substring(25, 28);
		System.out.println(val);
		*/
	}

}
