package programs2024;

public class RemoveNumFromAlpha {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "Testing1234";
		String alpha=""; 
		char[] ch = str.toCharArray();
		
		for(int i=0; i <=str.length()-1; i++) {
			
			if(!Character.isDigit(ch[i])) {
				alpha = alpha+ch[i];
				
			}
			
		/*	if(!Character.isAlphabetic(ch[i])) {    //if numbers required to print
				alpha = alpha+ch[i];
			} */
			
		}
		System.out.println(alpha);
		

	}

}
