package programs2024;

public class PalindromeEx {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String str = "radar" , palinString = "";
		
		for(int i=str.length()-1; i>=0; i--) {
			palinString = palinString + str.charAt(i);
		}
		
		if(str.equals(palinString)) {
			System.out.println("Plaindrome");
		} else {
			System.out.println("not plaindrome");
		}

	}

}
