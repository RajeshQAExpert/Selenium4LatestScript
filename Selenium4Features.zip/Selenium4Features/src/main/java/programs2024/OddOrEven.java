package programs2024;

public class OddOrEven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int i = 7;
		
		if(i%2==0) {
			System.out.println("Given number is Even");
		} else {
			System.out.println("Given number is odd");
		}
	}

}
