package programs2024;

public class MaximumOccuringChar2 {
	
	/*
	 So, the line count[str.charAt(i)]++; effectively increments the count of the character at index i in the string str by 1.
	  It's commonly used in scenarios where you need to count occurrences of characters in a string and update the counts in an array for further processing 
	 
	 */

			   public static void main(String[] args) {
				   
			      String str = "apple";
			      
			      char ch = ' ';
			      
			      int maxValue = 0;
			      
			      int count[] = new int[256];
			      
			      for (int i = 0; i <str.length(); i++) {
			         count[str.charAt(i)]++;
			         					              
			         if (count[str.charAt(i)] > maxValue) {
			        	 maxValue = count[str.charAt(i)];
			            ch = str.charAt(i);
			         }
			        
			      }  
			      System.out.println("Maximum occurring character is " + ch + " No Of Times = " + maxValue);
  
			   }
}
