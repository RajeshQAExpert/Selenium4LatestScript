package programs2024;

public class UpperCaseLowerCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		        String str = "TestTinG";
		        String uCase="", lCase="";

		        char[] chh = str.toCharArray();
		        
		        for (int i = 0; i < str.length(); i++) {
		            
		            if (Character.isUpperCase(chh[i])) {
		            	uCase = uCase+chh[i];
		                
		            } else {
		            	lCase = lCase + chh[i];	            	
		        }
   
		     
		}
		        System.out.println(uCase);
		        System.out.println(lCase);

	}

}
