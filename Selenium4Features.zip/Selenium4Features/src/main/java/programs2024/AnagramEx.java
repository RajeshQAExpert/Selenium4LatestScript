package programs2024;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;


public class AnagramEx {

	public static void main(String[] args) {
		
		
	
		
		/*
		 
		 Algorithm: 
		 
		STEP 1: START
		STEP 2: DEFINE str1 = "Brag", str2 = "Grab".
		STEP 3: CONVERT str1, str2 to lower-case.
		STEP 4: IF length of str1, str2 are not equal then PRINT "Not Anagram"
				else go to Step 5
		STEP 5: CONVERT str1, str2 to character arrays.
		STEP 6: SORT the arrays.
		STEP 7: COMPARE the arrays, IF equal then PRINT "Anagram"
				else
				PRINT "Not Anagram"
		STEP 8: END

		 
		 */
		
		String str1 = "Race", str2 = "Care"; 
		
		str1 = str1.toLowerCase();
		str2 = str2.toLowerCase();
		
		char[] string1 = str1.toCharArray();
		char[] string2 = str2.toCharArray();
		
		Arrays.sort(string1);
		Arrays.sort(string2);
		
		if(Arrays.equals(string1, string2)) {
			System.out.println("Given string is Anagram");
		} else {
			System.out.println("Not Anagram");
		}

	}

}
