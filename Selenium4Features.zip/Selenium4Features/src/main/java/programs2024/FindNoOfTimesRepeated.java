package programs2024;

public class FindNoOfTimesRepeated {

	public static void main(String[] args) {

		String str = "automationtesting";
		char chReq = 't'; 
		int occurance = 0;
		
		for(int i=0; i<str.length(); i++) {
		char ch = str.charAt(i);
			if(ch==chReq) {
				occurance = occurance+1;
			}
		}
		
	System.out.println(chReq + " - is present "+ occurance + " number of times ");	
	}

}
