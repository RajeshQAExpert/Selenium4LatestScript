package programs2024;

public class CntUCaseLCaseSpace {

	public static void main(String[] args) {
		
		
		/*		 
		  Pseudo Code: 
		  
		  1. Initialize the string to the variable 
		  2. Use for loop to iterate 
		  3. convert string into separate character using charAt
		  4. convert the character to int for handle the ascValue
		  5. check the condition based on the ascValue and print the result 
		 */

		String str = "TeSt @AuTomati!on* ";
		int uCase=0, lCase=0, spaceVal=0, speChar=0;
		
		for(int i=0; i<=str.length()-1; i++) {
			char ch =str.charAt(i);
			
			int ascValCnt = (int) ch;
			
			if(ascValCnt>=65 && ascValCnt<=90) {  				//UpperCase 65-90
				uCase = uCase+1;		
				
			} else if(ascValCnt==32) {							//Space 32
				spaceVal = spaceVal+1; 
				
			} else if(ascValCnt>=97 && ascValCnt<=122) {		//LowerCase 97-122
				lCase=lCase+1;
			} else {
				speChar = speChar+1;							//Handle in else status due to each special character has different ascvalue
			}	
		}
		
		System.out.println("uppserCase = " + uCase);
		System.out.println("LowerCase = "+lCase);
		System.out.println("Space = "+spaceVal);
		System.out.println("SpecialChar = "+speChar);
		
		
	}

}
