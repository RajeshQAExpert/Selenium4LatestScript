package programs2024;

import java.util.Arrays;

public class Test {
	
	public static void anagramEx() {
		
		String a = "care", b="Race";
		
		a = a.toLowerCase();
		b = b.toLowerCase();
		
		char[] cha= a.toCharArray();
		char[] chb = b.toCharArray();
		
		Arrays.sort(cha);     //It sorts the elements of the array in ascending order by default,
		Arrays.sort(chb);
		
		if(Arrays.equals(cha, chb)) {
			System.out.println("This is anagram");
		} else {
			System.out.println("not anagram");
		}
		
	}
	
			public static void arraysSortLogic() {   // Doubt
				int[] val = {3,5,1,6,2,7};
				
				Arrays.sort(val);
				
				
				
				for(int i=val.length-1; i>=0; i--) {
					System.out.print(i);
				}
			}
			
			
			public static void cntOfuCaselCase() {
				
				String str = "TesTinG ProJecT@#@#";
				
				int uCase=0, lCase=0, space=0, speChar =0;
				
				for(int i=0; i<=str.length()-1; i++) {
					char ch = str.charAt(i);
					int ascVal = (int) ch;
					
					if(ascVal>=65 && ascVal <=90) {
						uCase = uCase +1;
					} else if(ascVal==32) {
						space=space+1;
					} else if(ascVal>=97 && ascVal<=122) {
						lCase= lCase+1;
					} else {
						speChar=speChar+1;
					}
				}
				
				System.out.println(uCase+ " " + lCase + " " + space + " " + speChar);
				
			}
			

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test.anagramEx();
		//Test.arraysSortLogic();
		Test.cntOfuCaselCase();
		
	}

}
