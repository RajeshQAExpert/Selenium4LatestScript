package programs2024;

public class FindTheMissingInteger {

	public static void main(String[] args) {

	
		       // int[] array = {1, 2, 3, 4, /* ..., */ 99, 100}; // Array with one missing integer
		        
		
		 	int[] array = {1, 2, 6, 7,3};
		 	
		        // Calculate the sum of all integers from 1 to 100
		        int sumOfAllIntegers = 7 * (7 + 1) / 2; // Arithmetic sum formula

		        // Calculate the sum of all integers in the array
		        int sumOfArray = 0;
		        
		        for (int num : array) {
		            sumOfArray += num;
		        }

		        // Find the missing integer
		        int missingInteger = sumOfAllIntegers - sumOfArray;

		        System.out.println("The missing integer is: " + missingInteger);
		    }
	}
