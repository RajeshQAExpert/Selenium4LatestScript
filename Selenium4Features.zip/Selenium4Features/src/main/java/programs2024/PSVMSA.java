package programs2024;

public class PSVMSA {

	public static void main(String[] args) {

		/*
		 public - Access modifies which means it can be accessible from anywhere
		 static - Static method belongs to this class itself rather than instance of the class  
		 void - void is a keyword which tells doesn't return anything. 
		 main - This is the name of the method and entry point of the program
		 String[] args- This is the parameter that accepts the array of string as an arguments. 
		  
		  
	public static void main(String[] args) is declaring a method named main, 
	which is accessible from anywhere (public) and does not return any value (void). 
	It is a static method, meaning it belongs to the class itself rather than instances of the class. 
	It takes an array of strings as arguments, which can be used to pass command-line arguments to the program.
 	This method serves as the entry point of the Java program.
		 
		 */
		
	}

}
