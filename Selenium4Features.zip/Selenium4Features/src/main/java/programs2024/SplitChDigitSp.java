package programs2024;

public class SplitChDigitSp {

	public static void main(String[] args) {
		
		String alpha="", digit="", spe="", lCase=""; 
		
		String str = "testIng@1234";
		char[] ch = str.toCharArray();
		
		for(int i=0; i<str.length(); i++) {
			if(Character.isAlphabetic(ch[i])) {
				alpha=alpha+ch[i]; 
			} else if(Character.isDigit(ch[i])) {
				digit = digit + ch[i]; 
			} else {
					spe = spe+ch[i];
				}
			}
		System.out.println(alpha + "  "+ digit + " "+spe);
		}
		

	}


