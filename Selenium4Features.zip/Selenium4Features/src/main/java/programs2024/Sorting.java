package programs2024;

import java.util.Arrays;

public class Sorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String str = "testing";
		char[] ch = str.toCharArray();
		
		Arrays.sort(ch);
		
		System.out.println(ch);

	}

}
