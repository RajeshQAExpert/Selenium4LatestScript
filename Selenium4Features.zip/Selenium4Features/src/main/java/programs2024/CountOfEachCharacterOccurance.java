package programs2024;

public class CountOfEachCharacterOccurance {

	public static void main(String[] args) {

		String str= "testings";
		char[] ch = str.toCharArray();

		int cnt = 0;
		
		for(int i=0; i<str.length(); i++) { 
			
			for(int j=0; j<str.length(); j++) {
				
				if(ch[i]==ch[j]) {
					cnt=cnt+1;
				}
			}
			System.out.println(ch[i]+ "= " + cnt);
			cnt=0;
		}
		
	}

}
