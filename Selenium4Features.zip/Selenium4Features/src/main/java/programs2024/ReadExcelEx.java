package programs2024;

import java.io.FileInputStream;

import java.io.FileNotFoundException;

public class ReadExcelEx {

	public static void main(String[] args) throws FileNotFoundException {
		
		FileInputStream fis = new FileInputStream("spe/testData.xlsx");
		
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		
		int shtCnt = wb.getNumberOfSheets();
		
		for(int i=0; i<shtCnt; i++) {
			if(wb.getSheetName(i).equalsIgnoreCase("testdata")) {
				XSSFSheet sht = wb.getSheetAt(i);
				
				for(int j=1; j<=sht.getLastRowNum(); j++) {
					Row rows = sht.getRow(j);
					
					if(!rows==null) {
						for(Cell cell :rows) {
							System.out.print(cell+ "\t"); 
						}
					}
				}
			}
			
		}
		

	}

}
