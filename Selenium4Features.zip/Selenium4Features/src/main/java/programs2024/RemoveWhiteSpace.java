package programs2024;

public class RemoveWhiteSpace {

	public static void main(String[] args) {
	
		String str = "Rajesh kumar is Automation Tester";
		
		str = str.replaceAll("\\s", "");
		
		System.out.println(str);
		
		

	}

}
