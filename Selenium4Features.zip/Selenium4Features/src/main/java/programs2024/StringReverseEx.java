package programs2024;

public class StringReverseEx {
	
	public void strReverse() {
		String str = "Automation";
		
		for(int i=str.length()-1; i>=0; i--) {
			char ch = str.charAt(i);
			System.out.print(ch); 
		}
		
		//With Inbuild Methods: 
		System.out.println("  ================================");
		StringBuffer stBuffer = new StringBuffer(str);
		System.out.println(stBuffer.reverse());
		
	}
	
	
	public void reversetheWords() {
		String str= "This is called Automation";
		String splited="";
				
		String[] strArr = str.split(" ");
		
		for(int i=strArr.length-1; i>=0; i--) {
			splited = splited + strArr[i];
		} 
		System.out.println(splited);
	}
	
	
	public void reverseTheWordsInString() {
		
		String str = "Hello World";
		
		String[] splitedWords = str.split(" ");
		
		String reverseString = "";
		
		for (String stringSplitted : splitedWords) {
			
			String reverseWord="";
			
			for(int i=stringSplitted.length()-1; i>=0; i--) {
				reverseWord=reverseWord+stringSplitted.charAt(i);
				
			}
			
			reverseString = reverseString +reverseWord+ " ";			
		}
		
		System.out.println(reverseString);
		
	}
	
	public static void main(String[] args) {
		
		StringReverseEx stringReverse = new StringReverseEx();
		stringReverse.strReverse();
		stringReverse.reversetheWords();
		stringReverse.reverseTheWordsInString();
	}

}
