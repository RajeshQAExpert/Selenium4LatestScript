package programs2024;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;

public class Practisess {
	
	public static void main(String[] args) {
		
    System.setProperty("webdriver.chrome.driver", "d://chromedriver.exe");
    WebDriver driver = new ChromeDriver();
    driver.get("https://www.google.com");
    
    String st ="test";
    
    driver.findElement(By.xpath("")).sendKeys(st);
    
 		
	}
		}
		
		
