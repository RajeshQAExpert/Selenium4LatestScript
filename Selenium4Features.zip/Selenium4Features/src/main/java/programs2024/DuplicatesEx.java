package programs2024;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class DuplicatesEx {
	
	/*
	
	public void dupInt() {
		   int[] arrayValue = {5, 16, 22, 28, 5, 33, 37, 16, 22, 10};

	        // Create a HashSet to store unique elements
	        Set<Integer> uniqueElements = new HashSet<>();
	        // Create a HashSet to store duplicate elements
	        Set<Integer> duplicateElements = new HashSet<>();

	        for (int value : arrayValue) {
	            if (!uniqueElements.add(value)) {    //If you remove ! this it will print only unique values. 
	                // If value is already present in uniqueElements set, it's a duplicate
	                duplicateElements.add(value);
	            }
	        }

	        System.out.println("Duplicate elements in the array: " + duplicateElements);
	}
	*/
	//======================================================================================================
	
	public void dupStr() {
		
		        String[] str = {"Test", "Data", "Automation", "Test"};

		        // Create a HashSet to store unique elements
		        Set<String> uniqueElements = new HashSet<String>();
		        // Create a HashSet to store duplicate elements
		        Set<String> duplicateElements = new HashSet<String>();

		        for (String value : str) {
		            if (!uniqueElements.add(value)) {     //If you remove ! this it will print only unique values.
		                // If value is already present in uniqueElements set, it's a duplicate
		                duplicateElements.add(value);
		            }
		        }
		        System.out.println("Duplicate elements in the array: " + duplicateElements);
		        System.out.println("Unique elements are = " + uniqueElements);
    
		}
	
	
	
	public void dupString() {
		
		String str = "charactere";
	
		  char[] ch = str.toCharArray();		//toCharArray() method converts the given string into a sequence of characters
		  
		  for (int i = 0; i < str.length(); i++) {
		   for (int j = i + 1; j < str.length(); j++) {
		    if (ch[i] == ch[j]) {
		    	System.out.print(ch[i]);
			}
	}
		  }
	}
	
	
	public void removeDup() {
		
		String str = "charactere";
		char[] ch = str.toCharArray();
		
		 Set<Character> uniQue = new HashSet<Character>();
		 
		    for(int i = 0; i < str.length(); i++)     {	      
		    	uniQue.add(ch[i]);
		 
		} System.out.println(uniQue);
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DuplicatesEx duplicatesEx = new DuplicatesEx();
		//duplicatesEx.dupInt();
		//duplicatesEx.dupStr();
		duplicatesEx.dupString();
		duplicatesEx.removeDup();
			   }
			}
	