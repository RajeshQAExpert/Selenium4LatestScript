package programs2024;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class MissingAlphabets {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String str = "Testing";
		
		str = str.toLowerCase();
		
		//str = str.replace(" ", ""); // use this line if incase of any space in the given string
		
		String[] ch = str.split("");
		String[] alpha = "abcdefghijklmnopqrstuvwxyz".split("");
		
		
		Set<String> given = new HashSet<String>(Arrays.asList(ch));
		Set<String> expected = new HashSet<String>(Arrays.asList(alpha));
		
		expected.removeAll(given);
		System.out.println(expected);
		
		
	}

}
