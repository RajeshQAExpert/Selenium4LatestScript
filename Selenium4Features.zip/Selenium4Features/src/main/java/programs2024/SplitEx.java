package programs2024;

public class SplitEx {

	public static void main(String[] args) {
		
		String str = "This is the example of test automatin";
		
		String[] sptVal = str.split(" ");
		for(int i=0; i<=sptVal.length-1; i++) {
			
			if(sptVal[i].equalsIgnoreCase("example")) {
				System.out.println(sptVal[i]);
			}
			
		}
		
		
	}

}
