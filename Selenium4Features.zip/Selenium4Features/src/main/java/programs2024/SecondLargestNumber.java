package programs2024;

import java.util.SortedSet;
import java.util.TreeSet;

public class SecondLargestNumber {

	public static void main(String[] args) {
		
		int[] randomIntegers = { 1, 5, 4, 2, 8, 1, 1, 6, 7, 8 };   
		
		SortedSet<Integer> set = new TreeSet<Integer>(); 
		
		for (int intValue: randomIntegers) {
		    set.add(intValue);										// {1, 2, 4, 5, 6, 7, 8 } 
		    
		}
		
		//System.out.println(set.first());  // user this line if the
		
		
		//System.out.print(set+ " ");
		// Remove the maximum value; print the largest remaining item
		
		set.remove(set.last());								//// {1, 2, 4, 5, 6, 7 }
		System.out.println(set.last());
		
		
		
		
		
		

	}

}
