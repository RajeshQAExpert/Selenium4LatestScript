package programs2024;

public class FactorialEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int var =5, count=1 ;
		for (int i = 1; i <=var; i++) {
			count=count*i;
			System.out.println(count);

	}}

}
