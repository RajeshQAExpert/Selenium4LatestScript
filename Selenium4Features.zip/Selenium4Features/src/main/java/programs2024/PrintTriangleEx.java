package programs2024;

public class PrintTriangleEx {
	
	public void printPyramind() {
		
		int n =5;
		
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n-i; j++) {
				System.out.print(" ");
			}
			
			for(int k=1; k<=i; k++) {
				System.out.print("* ");
			}
			
			System.out.println();		
		}
	}
	
	
	public void printTriangle() {
		
		int n=5;
		
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	public void printStar() {
		
		for(int i=1; i<=5; i++) {
			for(int j=1; j<=5; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	public void printNumbers() {
		
		for(int i=0; i<5; i++) {
			for(int j=0; j<5; j++) {
				System.out.print(j+1 + " ");    //You can have j+1 as well if required
			}
			System.out.println();
		}
		
	}
	
	
	public void printRect() {
		
		int n=5;

		for(int i=0; i<n; i++){
			for(int j=0; j<n; j++){
				 
			if(i==0 || i== 4 || j==0 || j==4){
				System.out.print("*");					 
			} else {
				System.out.print(" "); 
				
			}
		}
			System.out.println();	
		   }
			
	}
	

	public static void main(String[] args) {		
		
		PrintTriangleEx obj = new PrintTriangleEx();
		//obj.printPyramind();
		//obj.printTriangle();
		//obj.printStar();
		//obj.printNumbers();
		obj.printRect();

	}

}
