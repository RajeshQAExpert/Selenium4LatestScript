package programs2024;

public class StringIndex {

	public static void main(String[] args) {
		
		String str = "testing";
		
		char ch = str.charAt(0);
		
		System.out.println(ch);
		
		
		//-------------------------------------
		
		int[] arrVal = {2, 4, 5};
		int add=0;
		
		for(int i=0; i<=arrVal.length-1; i++) {
			add = add+arrVal[i];
		}
		System.out.println(add);
		
	} 
}
