package intShortNotes;

public class DefaultValueOfLocalVariable {

	public static void main(String[] args) {

		
		
		/* int local; 
		
		System.out.println(local);
		
		Ans:
		Program Error: Compile time error which requires to initialize the values to the local variable	
		There is no default value for local variables
		
		
		*/
	}

}
