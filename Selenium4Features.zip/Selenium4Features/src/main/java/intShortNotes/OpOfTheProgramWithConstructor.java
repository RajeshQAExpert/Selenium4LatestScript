package intShortNotes;

public class OpOfTheProgramWithConstructor {
	
	
	public void test() {
		System.out.println("This is test");
	}
	
	
	public OpOfTheProgramWithConstructor(int a) {
		System.out.println("con is called");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OpOfTheProgramWithConstructor opOfTheProgramWithConstructor = new OpOfTheProgramWithConstructor(0);
		opOfTheProgramWithConstructor.test();
		
		
		
		//Notes: initElements method is used in pageFactory. it is used to initialize the page objects in the page object framework
	}

}
