package intShortNotes;

public class MavenProjectNameArtificateGroupID {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		/*
		 In Maven project, what would be the project name? 
		 
		 Artifact ID is the project name in the maven project
		 
		 
		 */

	}

}
