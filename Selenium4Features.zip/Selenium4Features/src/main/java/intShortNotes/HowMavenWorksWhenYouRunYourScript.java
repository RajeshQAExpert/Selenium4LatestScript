package intShortNotes;

public class HowMavenWorksWhenYouRunYourScript {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
			 How does maven work when you run your scripts:
	
		Ans:
			When we run our maven project, it will first create a local repository on you system
			all the downloaded files are stored in this repository. These are called artifacts

		Apart from local repository there is a maven central repository. when maven couldn't find the art
		artifact from local repository it will donwload from the central repository. 
		
		 
		 */

	}

}
