package intShortNotes;

public class CucumberAnnotaionsOrder {

	public static void main(String[] args) {
		
	 /*
	  
	  What happen to the end results when the annotations in cucumber Given, When and Then changes it;s order? 
	  Will the script run without error?
	  
	  Ans: 

	The script will run without any error
	The annotations in the scenario can be written in any order. However it is not the 
	best practise as it might cause confusions in the end report. 
	The recommended order is Given, When and Then. 

	Given - Defines the condition
	When - Defines the action
	Then - Defines the result of the action 
	  
	  
	  */
		
		

	}

}
