package tips;

public class MultipleClassesInClass {
}

 class demo{
	
 }
 
 class start{
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
