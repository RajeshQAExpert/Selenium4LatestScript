package tips;

public class SixtyEight {

	public static void main(String[] args) {

		char chars[] = { 'a', 'b', 'c' };
		String s = new String(chars);
		System.out.println(s);
		
		
	}

}
