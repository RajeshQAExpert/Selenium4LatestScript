package testNGEx;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.Color;
import org.testng.annotations.Test;

public class ParallelExeClass2 {
	
	@Test
	public void printColour() {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.com/gmail/about/");
		
		
		
		WebElement signInButton = driver.findElement(By.xpath("(//*[contains(text(),'Create an account')])[1]"));
		
		String btnColor = signInButton.getCssValue("background-color");
		
		//you cannot print the btncolor directly due to it will display the RGB color
		
		//To convert an RGB value to a color in Java, you can use the Color class
		//The name asHex() suggests that it might be related to converting something into its hexadecimal representation. 
		
		String clr = Color.fromString(btnColor).asHex();   
		System.out.println(clr);
		
		if(clr.equals("#1a73e8")) {
			System.out.println("As Expected");
		} else {
			System.out.println("invalid");
		}
		
	}

}
