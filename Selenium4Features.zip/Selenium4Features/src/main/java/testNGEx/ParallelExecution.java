package testNGEx;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ParallelExecution {
	
	@Test
	public void invokeBrowser() {
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.com");
		
		
		WebElement ele = driver.findElement(By.xpath("//*[contains(text(),'Gmail')]"));
		
		JavascriptExecutor js = ((JavascriptExecutor) driver);
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", ele);
		
		
		WebElement eleImg = driver.findElement(By.xpath("//*[contains(text(),'Images')]"));
		
		js.executeScript("arguments[0].setAttribute('style','background:yellow; border: 1px solid green;');", eleImg);
		
		
	}
	
	

}
