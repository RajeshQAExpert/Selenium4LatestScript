package intPrograms;

class ThisAndSuperKeyword2 {
	
	 /*
	 =====================================================================
	 This Keyword: 
			
			this keyword is reserved keyword
			this keyword is used to refer the current-class instance as well as static members 
			this keyword is used to access methods of the current class
			this keyword can be used any number of times.
	 */
	
		
		int a = 9;
		int b = 5;

		public void ex() {
			System.out.println("Parent Class Method");
			System.out.println(a+ " " + b);
		}
	}
	
	
	class thisChildExample extends ThisAndSuperKeyword2 {

		/*
		 * int a=10; int b=20;
		 */
		
		public void chEx() {
			
			this.a = 55; 
			this.b = 44;
			
			System.out.println(a + " " + b);
		}
		
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		thisChildExample obj = new thisChildExample();
		obj.chEx();
		

	}

}
