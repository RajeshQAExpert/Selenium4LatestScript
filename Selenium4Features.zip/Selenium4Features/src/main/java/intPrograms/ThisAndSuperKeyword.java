package intPrograms;

 class ThisAndSuperKeyword {
	
	/*
	 super Keyword:

		super keyword is reserved keyword
		super keyword is used to refer super-class instance as well as static members
		super keyword is used to access methods of the parent class
		super keyword can be used any number of times
		
		Notes: If you want to access the parent class data members you can use super keyword
		
		Notes: You cannot have more than one public class in same class
	 
	 */
		
		int a = 10;
		int b = 20;
		
		public void testMethod() {
			System.out.println("this is test method");
		}
	}
	
	
	 class chClass extends ThisAndSuperKeyword{
		
		public void chClassMethod() {
			
			super.a=100;
			System.out.println(super.a);
			
			super.b=50;
			System.out.println(super.b);
			
			testMethod();			
		}

			

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		chClass obj = new chClass();
		obj.chClassMethod();
		
	}

}
