package intPrograms;

public class HandleDisappearElement {
	
	//When you search the products in the search field cannot inspect due to it will disappeared as soon as move the mouse 

		/*
		 Install Selectors hub 
		 Inspect the browser 
		 Click Turn on Debugger under the selectors hub section (Right side section) 
		 (Screen will freeze after 5 to 10 seconds) 

		 */
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	
		

	}

}
