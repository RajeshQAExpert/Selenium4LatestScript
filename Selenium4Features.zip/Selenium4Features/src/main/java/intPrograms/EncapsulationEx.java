package intPrograms;

public class EncapsulationEx {

	
	private int accNumber;    //instance Variable
	private String name;
	private int age;
	
/*	
	public void testMethod(int age) {
		this.age = age;
	}
	*/     // You cannot access those private variables with the normal methods 
	
	public int getAccNumber() {
		return accNumber;
	}


	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}

	public static void main(String[] args) {

		EncapsulationEx obj = new EncapsulationEx();
		obj.setAccNumber(12345);
		obj.setName("Kumar");
		obj.setAge(18);
		
		obj.setAccNumber(678910); //This will overwrite the previous values
		obj.setName("Test");
		obj.setAge(30);
		
		System.out.println(obj.getAccNumber());
		System.out.println(obj.getName());
		System.out.println(obj.getAge());
		
		
		
		
	}

}
