package datePicker;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CalenderHandling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		WebDriver driver = new ChromeDriver(); 
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://seleniumpractise.blogspot.com/2016/08/how-to-handle-calendar-in-selenium.html");
		
		WebElement calenderEle = driver.findElement(By.id("datepicker"));
		if(calenderEle.isEnabled()) {
			calenderEle.click();
			
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='ui-datepicker-next ui-corner-all']")));
			
			String month = driver.findElement(By.xpath("//*[@class='ui-datepicker-month']")).getText();
			String year = driver.findElement(By.xpath("//*[@class='ui-datepicker-year']")).getText();
			
			
			while (!(month.equals("August") && year.equals("2024"))) {
				
				driver.findElement(By.xpath("//*[text()='Next']")).click();
				
				month = driver.findElement(By.xpath("//*[@class='ui-datepicker-month']")).getText();
				year = driver.findElement(By.xpath("//*[@class='ui-datepicker-year']")).getText();
				
			}

			//To print all the days in a particular month
			/*  
			 List<WebElement> ele = driver.findElements(By.xpath("//a[@class='ui-state-default']"));
		for(WebElement val : ele) {
			System.out.println(val.getText());
		}
			 */
			
			//driver.findElement(By.xpath("//*[text()='3']")).click();
			
			int daySize = 	driver.findElements(By.xpath("//a[@class='ui-state-default']")).size();
		
		for(int i=0; i<=daySize-1; i++) {
			String days = driver.findElements(By.xpath("//a[@class='ui-state-default']")).get(i).getText();
			
			if(days.equalsIgnoreCase("3")) {
				 driver.findElements(By.xpath("//a[@class='ui-state-default']")).get(i).click();
				 break;
			}
		}
	}
	}
}
