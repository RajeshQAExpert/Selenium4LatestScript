package practice;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetMethods {

	public static void main(String[] args) {


		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.com");
		String pgURL = driver.getTitle();
		
		JavascriptExecutor ex = (JavascriptExecutor) driver;
		ex.executeScript("Arguments[0].scrollIntoView(true)" );
		
		
		
	
		
		
	}

}
