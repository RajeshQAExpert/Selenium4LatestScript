package practice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class HandleSSLCeritificates {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		ChromeOptions handleSSL = new ChromeOptions();
		handleSSL.setAcceptInsecureCerts(true);
				
		WebDriver driver = new ChromeDriver(handleSSL); //pass chromeoptions object as an argument to the chromedriver constructor 
		driver.manage().window().maximize();
		driver.get("https://www.expired.badssl.com/");

	}

}
