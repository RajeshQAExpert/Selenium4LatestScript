package practice;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.io.FileHandler;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;


public class FullPageScreenshot {
	
	
	public static void main(String[] args) throws IOException {
		
		//ChromeOptions options = new ChromeOptions();
		//options.add_argument('--start-maximized');
		//options.add_argument('--Control+Cmd+F');
	
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.get("https://naukri.com");
	
	
	
	
	AShot aSht = new AShot();
	Screenshot sc = aSht.shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
	ImageIO.write(sc.getImage(), "PNG", new File("D:\\FullPageScreenshot.png"));

}
}