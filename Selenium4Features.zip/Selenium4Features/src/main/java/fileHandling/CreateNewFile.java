package fileHandling;

import java.io.File;
import java.io.IOException;

public class CreateNewFile {
	
	
	}
}
