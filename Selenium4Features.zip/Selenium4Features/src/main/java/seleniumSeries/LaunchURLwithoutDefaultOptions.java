package seleniumSeries;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class LaunchURLwithoutDefaultOptions {

	public static void main(String[] args) {

		String url = "https://www.google.com/";
		WebDriver driver = new ChromeDriver();
		
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("window.location = \'"+url+"\'");    // THis is called escape method	
	}

}
