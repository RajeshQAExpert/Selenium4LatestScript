package seleniumSeries;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class UnderlineElement {

	public static void main(String[] args) throws InterruptedException {
		

		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.com/");
		
		WebElement ele = driver.findElement(By.xpath("//a[contains(text(),'தமிழ்')]"));
		
		Actions actions = new Actions(driver);
		actions.moveToElement(ele).perform();    // For underline the element
		Thread.sleep(5000);
		
		//actions.moveToElement(ele).build().perform();
		
		//actions.moveToElement(ele).click().perform();
		
		actions.moveToElement(ele).contextClick().build().perform();  //Right click
		
		//actions.click(ele).build().perform();
		
		
		
		//ele.getCssValue("text-decoration");
	
	
	}

}
