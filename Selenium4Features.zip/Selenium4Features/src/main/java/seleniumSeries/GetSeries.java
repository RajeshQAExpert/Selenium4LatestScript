package seleniumSeries;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class GetSeries {
	
	public static void main(String[] args) {
	
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://www.google.com");
	
	
	
	String winHan = driver.getWindowHandle();		// Handle only one window
	System.out.println(winHan);
	
	//Set<String> winHandle = driver.getWindowHandles();	//more than one window
	
	String pgtitle = driver.getTitle();
	System.out.println(pgtitle);
	
	String pgSource = driver.getPageSource();
	//System.out.println(pgSource);
	
	String strCurrentURL = driver.getCurrentUrl();
	System.out.println(strCurrentURL);
	
	}

}
