package seleniumSeries;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CompareTwoDropDown {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demoqa.com/select-menu");
		
		List<WebElement> ele1 = driver.findElements(By.id("oldSelectMenu"));
		List<WebElement> ele2 = driver.findElements(By.id(" css-2b097c-container"));
		
		for(int i=0; i<=ele1.size()-1; i++ ) {
			for(int j=0; j<=ele2.size()-1; j++) {
				String str1 = driver.findElements(By.id("oldSelectMenu")).get(i).getText();
				String str2 = driver.findElements(By.id(" css-2b097c-container")).get(j).getText();
				if(str1.equalsIgnoreCase(str2)) {
					System.out.println(str1);
				}
			}
				
		}
		
	}

}
