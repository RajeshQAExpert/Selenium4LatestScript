package seleniumSeries;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.Color;

public class PrintColorOfTheButton {

	public static void main(String[] args) {
	
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.com/gmail/about/");
		
		
		
		WebElement signInButton = driver.findElement(By.xpath("(//*[contains(text(),'Create an account')])[1]"));
		
		String btnColor = signInButton.getCssValue("background-color");
		
		//you cannot print the btncolor directly due to it will display the RGB color
		
		//To convert an RGB value to a color in Java, you can use the Color class
		//The name asHex() suggests that it might be related to converting something into its hexadecimal representation. 
		
		String clr = Color.fromString(btnColor).asHex();   
		System.out.println(clr);
		
		if(clr.equals("#1a73e8")) {
			System.out.println("As Expected");
		} else {
			System.out.println("invalid");
		}
		
		
		
		/*
		 * driver.get("https://www.tutorialspoint.com/about/about_careers.htm"); //
		 * identify text WebElement t = driver.findElement(By.tagName("h1")); //obtain
		 * color in rgba String s = t.getCssValue("color"); // convert rgba to hex
		 * String c = Color.fromString(s).asHex(); System.out.println("Color is :" + s);
		 * System.out.println("Hex code for color:" + c); driver.quit();
		 */
		/*
		String url = "https://www.tutorialspoint.com/index.htm";
	      driver.get(url);
	      //getting color attribute with getCssValue()
	      String colr = driver.findElement(By.xpath("//*[text()=’GATE Exams’]"))
	      .getCssValue("color");
	      //getting background color attribute with getCssValue()
	      String bckgclr = driver.findElement(By.xpath("//*[text()=’GATE Exams’]"))
	      .getCssValue("background-color");
	      System.out.println(colr);
	      System.out.println(bckgclr);
	      driver.close();
*/
	}

}
