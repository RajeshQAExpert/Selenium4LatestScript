package exceptionHandling;

import java.io.File;
import java.io.IOException;

public class ExceptionHandlingEx {
	
	/*
	 (I)Serializable <-- (c)Throwable <-- (c) Exception <-- (c) IOException <-- (c) FileNotFoundException 

				     (c) Exception <-- (c) RuntimeException <-- (c) WebDriverException <-- (c) NotFoundException <-- (c) NoSuchElementException
	 
	 Explanation: 
	 
	 try block encloses the code that might throw an exception
	 
	 The catch block follows the try block and specifies the type of exception that the code inside the try block might throw.
	 The catch block is used to catch and handle the exception.
	 IOException e: Inside the catch block, the exception object is referenced by e. 
	 The IOException caught during the execution of the try block is stored in this variable.
	 //IOException occurs when an input or output operation fails or gets interrupted. 
	  This can happen for various reasons such as: File not found. Permission issues.
	 
	 The stack trace includes information about the exception such as its type, message, and the sequence of method calls that led to the exception. 
	 This helps in debugging and diagnosing the cause of the exception.
	 which prints the throwable along with other details like the line number and class name where the exception occurred.
	 The printStackTrace() is very useful in diagnosing exceptions.
	 */
	

	public static void main(String[] args)  {

		String file = "D:\\Testing\\testdata.txt";
		File path = new File(file);
		
		try {
			path.createNewFile();
			
		} catch (IOException e) {  
			e.printStackTrace();   
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("Executed Successfully");
		}
	}

}
